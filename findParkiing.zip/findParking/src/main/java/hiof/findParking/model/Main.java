package hiof.findParking.model;

public class Main {
//    Laget for å teste klasser som er i model.

}
