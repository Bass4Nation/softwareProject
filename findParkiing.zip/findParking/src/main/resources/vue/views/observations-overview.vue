<template id="observations-overview">
   <div>
       <h1>Planet systems</h1>
        <ul class="observations-overview-list">
            <li v-for="observation in observations">
                <a :href="`/observations/${observation.name.trim()}`" class="link-to-observation-details">
                    <div class="single-observation-container" >
                        <h1>{{observation.id}} - {{observation.name}}</h1>
                        <h1>{{observation.animal.name}}</h1>
                        <img v-if="observation.pictureUrl" class="observation-cover-image" v-bind:src="observation.pictureUrl">
                        <img v-else class="cover-image-frontpage" src="https://upload.wikimedia.org/wikipedia/commons/thumb/d/d9/Icon-round-Question_mark.svg/480px-Icon-round-Question_mark.svg.png">
                    </div>
                </a>
            </li>
        </ul>
   </div>
</template>
<script>
    Vue.component("observations-overview", {
        template: "#observations-overview",
        data: () => ({
            observations: [],
        }),
        created() {
            fetch("/api/observations")
                .then(res => res.json())
                .then(res => {
                   this.observations = res;
                })
                .catch(() => alert("Error while fetching observations"));
        }
    });
</script>
<style>
    li{
        list-style-type: none;
    }

    .observation-overview-list{
        display: flex;
        flex-wrap: wrap;
        justify-content: center;
    }

    .observation-overview-list li{
        padding: 10px;
        border: 1px solid white;
        border-radius: 15px;
    }

    .link-to-observation-details{
        width: 400px;
        height:100px;
        text-decoration: none;
        color: white;
    }

    div.single-observation-container{
        overflow: hidden;
        width: 500px;
        background-color: #000000;
        margin: 0 auto;
        opacity: 0.96;
        text-align: center;
    }

    img.observation-cover-image {
        height: 200px;
        width: 200px;
    }

    div.single-observation-container:hover{
        opacity: 1.0;
        overflow: hidden;
        -webkit-box-shadow: 10px 10px 5px 0px rgba(0,0,0,0.25);
        -moz-box-shadow: 10px 10px 5px 0px rgba(0,0,0,0.25);
        box-shadow: 10px 10px 5px 0px rgba(0,0,0,0.25);
    }

    img.cover-image-frontpage {
        height: auto;
        width: 50%;
        padding-bottom: 20px;
        max-height: 200px;
    }

</style>