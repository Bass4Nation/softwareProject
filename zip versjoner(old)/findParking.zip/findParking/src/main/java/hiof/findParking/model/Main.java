package hiof.findParking.model;

public class Main {
//    Laget for å teste hele prosjektet pluss nettsiden.


    public static void main(String[] args) {
        System.out.println("Dette er main i model");

//        For loop som teller til hundre. For å sjekke om main virker
        for(int i = 0; i <= 100; i++){
            System.out.println(i);
        }

    }
}
