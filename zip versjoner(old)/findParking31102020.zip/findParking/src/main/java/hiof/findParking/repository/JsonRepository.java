package hiof.findParking.repository;

public class JsonRepository {
}
