//import hiof.findParking.model.Annonse;
//import org.junit.jupiter.api.Assertions;
//import org.junit.jupiter.api.Test;
//
//public class Er_Annonsen_ledig_eller_ikke {
////    Lagt alle testene in i en fil som nevner fint hva den tester
////    LeapYear_In_Calender_Test
//
//    @Test()
//    public void erAnnonsenLedig() {
//        boolean ledig = true;
//        String expected = "Ledig";
//        Annonse annonse = new Annonse();
//        String actual = annonse.ledigStatus(ledig);
//
//      Assertions.assertEquals(expected,actual);
//    }
//}
//
