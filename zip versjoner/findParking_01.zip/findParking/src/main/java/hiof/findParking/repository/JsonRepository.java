package hiof.findParking.Repository;

public class JsonRepository {
}
